<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Gbook extends Model
{
    public $timestamps = false;
}
