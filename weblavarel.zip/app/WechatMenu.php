<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class WechatMenu extends Model
{
    protected $table = 'wechatmenu';
    public $timestamps = false;
}
