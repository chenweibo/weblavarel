<?php $__env->startSection('title','新闻中心'.'-'.$system['title']); ?>
<?php $__env->startSection('keywords', $system['keywords']); ?>
<?php $__env->startSection('description', $system['description']); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('home/header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<script type="text/javascript">
    var hdnav='2';
    $('.pcnavBar ul.pcnav>li:eq('+hdnav+')').addClass("on");
</script>
<script type="text/javascript">
 jQuery(".pcnavBar .pcnav").slide({ type:"menu",  titCell:".m", targetCell:".sub",effect:"slideDown", delayTime:500, triggerTime:0,returnDefault:true  });
</script>

<div class="nyslide" style="background:url(<?php echo e(asset('static/home/img/newsny.jpg')); ?>) no-repeat center top; background-size:cover;">
    <ul>
        <li class="ch wow fadeInLeft" data-wow-delay="0.3s">
            <span class="cn">新闻资讯</span>
            <span class="en text-uppercase">news </span>
        </li>
    </ul>
</div>

<!--inspage.start-->

<div id="inspage">
    <div class="inspagebox clearfix">

        <!--ipad.mobile-->
        <div class="mobinsrightnav clearfix ">
            <a href="">
                新闻资讯
            </a>
        </div>
        <script type="text/javascript">
            var hdnav='0';
            $('.mobinsrightnav>a:eq('+hdnav+')').addClass("cur");
        </script>
        <div class="insleft">
            <div class="title wow fadeInUp">
                <p class="cn">了解金安电气的最新动态</p>
                <p class="en">Learn about the latest developments in Jinan</p>
            </div>
            <div class="insinfo">
                <div class="newsinfo clearfix wow fadeInUp">
                   <ul class="newslist">
                     <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <li>
                           <a href="<?php echo e(route('newsView',$v->id)); ?>" class="clearfix">
                               <span class="img">
                                   <img src="<?php echo e(asset('static/uploads'.'/'.$v->img)); ?>"/>
                               </span>
                               <span class="con">
                                   <div class="newstit"><?php echo e($v->name); ?></div>
                                   <div class="newsbox"><?php echo e(getstring($v->info,0,100)); ?></div>
                                   <div class="date"><?php echo e($v->time); ?></div>
                               </span>
                           </a>
                       </li>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   </ul>
                </div>
            </div>
        </div>
        <div class="insrightnav">
            <a href="">
                新闻资讯
            </a>
        </div>
        <script type="text/javascript">
            var hdnav='0';
            $('.insrightnav>a:eq('+hdnav+')').addClass("cur");
        </script>
    </div>
</div>

<div id="backhome">
    <a href="/"><span><i></i>返回首页</span></a>
</div>

<?php echo $__env->make('home/foot', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>