<?php $__env->startSection('title','设备展示'.'-'.$system['title']); ?>
<?php $__env->startSection('keywords', $system['keywords']); ?>
<?php $__env->startSection('description', $system['description']); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('home/header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<script type="text/javascript">
    var hdnav='3';
    $('.pcnavBar ul.pcnav>li:eq('+hdnav+')').addClass("on");
</script>
<script type="text/javascript">
 jQuery(".pcnavBar .pcnav").slide({ type:"menu",  titCell:".m", targetCell:".sub",effect:"slideDown", delayTime:500, triggerTime:0,returnDefault:true  });
</script>

<div class="nyslide" style="background:url(<?php echo e(asset('static/home/img/downloadny.jpg')); ?>) no-repeat center top; background-size:cover;">
    <ul>
        <li class="ch wow fadeInLeft" data-wow-delay="0.3s">
            <span class="cn">下载中心</span>
            <span class="en text-uppercase">Download Center</span>
        </li>
    </ul>
</div>

<!--inspage.start-->

<div id="inspage">
    <div class="inspagebox clearfix">

        <!--ipad.mobile-->
        <div class="mobinsrightnav clearfix ">
          <a href="<?php echo e(route('download')); ?>">
              下载中心
          </a>
        </div>
        <script type="text/javascript">
            var hdnav = '0';
            $('.mobinsrightnav>a:eq(' + hdnav + ')').addClass("cur");
        </script>
        <div class="insleft">
            <div class="title wow fadeInUp">
                <p class="cn">您可以在此处下载您需要的资料</p>
                <p class="en">You can download the information you need here</p>
            </div>
            <div class="insinfo">
                <div class="downloadinfo clearfix wow fadeInUp">
                    <div class="tit">
                        <span>文档名称</span>
                        <span>文档格式</span>
                        <span>文档大小</span>
                    </div>
                    <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <div class="list clearfix">

                          <a target="_blank"  style="cursor:pointer "  onclick="getfile(event,'<?php echo e($v['id']); ?>')"  ><span><?php echo e($v['name']); ?></span></a>
                          <span><?php echo e(substr(strrchr($v['down'], '.'), 1)); ?></span>
                          <span><?php echo e(round($v['filesize'],3)); ?>MB</span>
                      </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
        <script type="text/javascript">
         function  getfile(event,id){
           var zz =$(event.target);
           var jz;
           var url = "<?php echo e(route('userdown')); ?>";
           $.ajax({
               type: "POST",
               url: url,
               async: false, 
               headers: {
                   'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
               },
               data:{'id':id},
               beforeSend: function () {
                   jz = layer.load(0, {shade: false}); //0代表加载的风格，支持0-2
               },
               error: function (request) {
                   layer.close(jz);
                   layer.msg('出错联系管理员');
               },
               success: function (data) {
                   //关闭加载层
                   layer.close(jz);
                   if (data.code == 1) {
                      window.open (data.url);
                   } else {
                    $('.login_link').click();
                   }
               }
           });
          }
        </script>
        <div class="insrightnav">
            <a href="<?php echo e(route('download')); ?>">
                下载中心
            </a>
        </div>
        <script type="text/javascript">
            var hdnav = '0';
            $('.insrightnav>a:eq(' + hdnav + ')').addClass("cur");
        </script>
    </div>
</div>

<div id="backhome">
    <a href="/"><span><i></i>返回首页</span></a>
</div>

<?php echo $__env->make('home/foot', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>