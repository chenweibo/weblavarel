<?php $__env->startSection('title','地图导航'.'-'.$system['title']); ?>
<?php $__env->startSection('keywords', $system['keywords']); ?>
<?php $__env->startSection('description', $system['description']); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('home/header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<script type="text/javascript">
    var hdnav='6';
    $('.pcnavBar ul.pcnav>li:eq('+hdnav+')').addClass("on");
</script>
<script type="text/javascript">
 jQuery(".pcnavBar .pcnav").slide({ type:"menu",  titCell:".m", targetCell:".sub",effect:"slideDown", delayTime:500, triggerTime:0,returnDefault:true  });
</script>

<div class="nyslide" style="background:url(<?php echo e(asset('static/home/img/mapny.jpg')); ?>) no-repeat center top; background-size:cover;">
    <ul>
        <li class="ch wow fadeInLeft" data-wow-delay="0.3s">
            <span class="cn">地图导航</span>
            <span class="en text-uppercase">map navigation</span>
        </li>
    </ul>
</div>

<!--inspage.start-->

<div id="inspage">
    <div class="inspagebox clearfix">

        <!--ipad.mobile-->
        <div class="mobinsrightnav clearfix ">
          <a href="<?php echo e(route('contact')); ?>">
              联系方式
          </a>
          <a href="<?php echo e(route('map')); ?>">
              地图导航
          </a>
        </div>
        <script type="text/javascript">
            var hdnav='1';
            $('.mobinsrightnav>a:eq('+hdnav+')').addClass("cur");
        </script>
        <div class="insleft">
            <div class="title wow fadeInUp">
                <p class="cn">您可以按照地图导航找到我司的位置</p>
                <p class="en">You can follow the map navigation to find our position</p>
            </div>
            <div class="insinfo">
                <div class="mapinfo clearfix wow fadeInUp">
                    <iframe src="<?php echo e(asset('static/home/css/map2.html')); ?>" width="100%" height="100%" frameborder="0" scrolling="no"></iframe>
                </div>
            </div>
        </div>
        <div class="insrightnav">
          <a href="<?php echo e(route('contact')); ?>">
              联系方式
          </a>
          <a href="<?php echo e(route('map')); ?>">
              地图导航
          </a>
        </div>
        <script type="text/javascript">
            var hdnav='1';
            $('.insrightnav>a:eq('+hdnav+')').addClass("cur");
        </script>
    </div>
</div>

<div id="backhome">
    <a href="/"><span><i></i>返回首页</span></a>
</div>

<?php echo $__env->make('home/foot', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>