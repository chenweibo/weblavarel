<?php $__env->startSection('title', $data->name.'-'.$system['title']); ?>
<?php $__env->startSection('keywords', $system['keywords']); ?>
<?php $__env->startSection('description', $system['description']); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('home/header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<script type="text/javascript">
    var hdnav = '1';
    $('.pcnavBar ul.pcnav>li:eq(' + hdnav + ')').addClass("on");
</script>

<div class="nyslide" style="background:url(<?php echo e(asset('static/home/img/prony.jpg')); ?>) no-repeat center top; background-size:cover;">
    <ul>
        <li class="ch wow fadeInLeft" data-wow-delay="0.3s">
            <span class="cn">产品汇总</span>
            <span class="en text-uppercase">Product summary</span>
        </li>
    </ul>
</div>

<!--inspage.start-->

<div id="inspage">
    <div class="inspagebox clearfix">

        <!--ipad.mobile-->
        <div class="mobinsrightnav clearfix ">
            <a href="pro.html">
                产品汇总
            </a>
            <a href="device.html">
                设备展示
            </a>
        </div>
        <script type="text/javascript">
            var hdnav = '0';
            $('.mobinsrightnav>a:eq(' + hdnav + ')').addClass("cur");
        </script>
        <div class="insleft">
            <div class="title wow fadeInUp">
                <p class="cn">专业生产经营气动元件，电磁铁、制动器等150多个系列</p>
                <p class="en">Professional production and operation of pneumatic components...</p>
            </div>
            <div class="insinfo">
                <div class="proinfo clearfix wow fadeInUp">
                  <ul class="pronav clearfix">
                   <?php $__currentLoopData = $cate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="m">
                        <a <?php if($v['id'] == $nn->id): ?>
                         class="cur"
                        <?php endif; ?> href="javascript:void(0);"><?php echo e($v['name']); ?></a>
                        <?php if(!empty($v['children'])): ?>
                          <ul class="prosub">
                            <?php $__currentLoopData = $v['children']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <li><a href="<?php echo e($vo['rewrite']); ?>"><?php echo e($vo['name']); ?></a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </ul>
                        <?php endif; ?>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                    <script type="text/javascript">
                        jQuery(".pronav").slide({
                            type: "menu",
                            titCell: ".m",
                            trigger:"click",
                            targetCell: "ul.prosub",
                            effect: "slideDown",
                            delayTime: 500,
                            triggerTime: 0,
                            returnDefault: true
                        });
                    </script>
                    <script type="text/javascript">
                        var hdnav = '0';
                        $('.pronav>li>a:eq(' + hdnav + ')').addClass("cur");
                    </script>
                    <div class="proview">
                       <div class="proDet_top clearfix">
                           <div class="proDet_title">
                             <img src="<?php echo e(asset('static/home/img/pro_det_icon.png')); ?>">
                            <a href="/<?php echo e($catename->rewrite); ?>"><?php echo e($catename->name); ?></a> — <strong><?php echo e($data->name); ?></strong>
                           </div>
                           <a onclick="history.go(-1)" class="back2">返回列表</a>
                       </div>
                        <div class="proDet_scroll">
                            <div class="slider8">
                              <?php $__currentLoopData = codeimg($data->moreimg); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="slide"><img src="<?php echo e(asset('static/uploads'.'/'.$v)); ?>"></div>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                       <script src="<?php echo e(asset('static/home/js/jquery.bxslider.js')); ?>"></script>
                        <script>
                            $(document).ready(function(){
                                $('.slider8').bxSlider({
                                    adaptiveHeight: true,
                                    startSlides: 0,
                                    slideMargin: 10,
                                    infiniteLoop:false
                                });
                            });
                        </script>
                        <div class="detail">
                            <div class="detail-tit">详情描述</div>
                             <div class="detail-info"><?php echo $data->info; ?></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="insrightnav">
            <a href="pro.html">
                产品汇总
            </a>
            <a href="device.html">
                设备展示
            </a>
        </div>
        <script type="text/javascript">
            var hdnav = '0';
            $('.insrightnav>a:eq(' + hdnav + ')').addClass("cur");
        </script>
    </div>
</div>

<div id="backhome">
    <a href=""><span><i></i>返回首页</span></a>
</div>


<?php echo $__env->make('home/foot', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>