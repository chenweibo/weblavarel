<?php $__env->startSection('title', '企业文化'.'-'.$system['title']); ?>
<?php $__env->startSection('keywords', $system['keywords']); ?>
<?php $__env->startSection('description', $system['description']); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('home/header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<script type="text/javascript">
    var hdnav = '0';
    $('.pcnavBar ul.pcnav>li:eq(' + hdnav + ')').addClass("on");
</script>
  <script type="text/javascript">
   jQuery(".pcnavBar .pcnav").slide({ type:"menu",  titCell:".m", targetCell:".sub",effect:"slideDown", delayTime:500, triggerTime:0,returnDefault:true  });
</script>
<div class="nyslide" style="background:url(<?php echo e(asset('static/home/img/cultureny.jpg')); ?>) no-repeat center top; background-size:cover;">
    <ul>
        <li class="ch wow fadeInLeft" data-wow-delay="0.3s">
            <span class="cn">企业文化</span>
            <span class="en text-uppercase">company culture</span>
        </li>
    </ul>
</div>
<!--inspage.start-->
<div id="inspage">
    <div class="inspagebox clearfix">

        <!--ipad.mobile-->
        <div class="mobinsrightnav clearfix ">
          <a href="<?php echo e(route('about')); ?>">
              公司简介
          </a>
          <a href="<?php echo e(route('culture')); ?>">
              企业文化
          </a>
          <a href="<?php echo e(route('honor')); ?>">
              荣誉证书
          </a>
        </div>
        <script type="text/javascript">
            var hdnav='1';
            $('.mobinsrightnav>a:eq('+hdnav+')').addClass("cur");
        </script>
        <div class="insleft">
            <div class="title wow fadeInUp">
                <p class="cn">浙江金安电气有限公司</p>
                <p class="en">ZheJiang Jinan Electric Co., Ltd</p>
            </div>
            <div class="insinfo">
                <div class="cultureinfo clearfix wow fadeInUp">
                   <div class="part1">
                       <img src="<?php echo e(asset('static/home/img/cultureinfobg.jpg')); ?>"/>
                   </div>
                </div>
            </div>
        </div>
        <div class="insrightnav">
          <a href="<?php echo e(route('about')); ?>">
              公司简介
          </a>
          <a href="<?php echo e(route('culture')); ?>">
              企业文化
          </a>
          <a href="<?php echo e(route('honor')); ?>">
              荣誉证书
          </a>
        </div>
        <script type="text/javascript">
            var hdnav='1';
            $('.insrightnav>a:eq('+hdnav+')').addClass("cur");
        </script>
    </div>
</div>

<div id="backhome">
    <a href="/"><span><i></i>返回首页</span></a>
</div>

<?php echo $__env->make('home/foot', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>