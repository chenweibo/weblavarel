<?php $__env->startSection('title','设备展示'.'-'.$system['title']); ?>
<?php $__env->startSection('keywords', $system['keywords']); ?>
<?php $__env->startSection('description', $system['description']); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('home/header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<script type="text/javascript">
    var hdnav='1';
    $('.pcnavBar ul.pcnav>li:eq('+hdnav+')').addClass("on");
</script>
<script type="text/javascript">
 jQuery(".pcnavBar .pcnav").slide({ type:"menu",  titCell:".m", targetCell:".sub",effect:"slideDown", delayTime:500, triggerTime:0,returnDefault:true  });
</script>


<div class="nyslide" style="background:url(<?php echo e(asset('static/home/img/deviceny.jpg')); ?>) no-repeat center top; background-size:cover;">
    <ul>
        <li class="ch wow fadeInLeft" data-wow-delay="0.3s">
            <span class="cn">设备展示</span>
            <span class="en text-uppercase">equipment Exhibition</span>
        </li>
    </ul>
</div>

<!--inspage.start-->

<div id="inspage">
    <div class="inspagebox clearfix">

        <!--ipad.mobile-->
        <div class="mobinsrightnav clearfix ">
          <a href="<?php echo e(route('product')); ?>">
              产品汇总
          </a>
          <a href="<?php echo e(route('device')); ?>">
              设备展示
          </a>
        </div>
        <script type="text/javascript">
            var hdnav = '1';
            $('.mobinsrightnav>a:eq(' + hdnav + ')').addClass("cur");
        </script>
        <div class="insleft">
            <div class="title wow fadeInUp">
                <p class="cn">精良的设备是一家企业的重要保障</p>
                <p class="en">Sophisticated equipment is an important guarantee for an enterprise</p>
            </div>
            <div class="insinfo">
                <div class="honorinfo clearfix wow fadeInUp">
                  <link rel="stylesheet" href="<?php echo e(asset('static/home/css/lightbox.css')); ?>">
                  <script type="text/javascript" src="<?php echo e(asset('static/home/js/base.js')); ?>"></script>
                  <script type="text/javascript" src="<?php echo e(asset('static/home/js/jquery.lightbox.js')); ?>"></script>
                    <ul class="honor">
                      <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <li>
                           <a href="<?php echo e(asset('static/uploads'.'/'.$v->img)); ?>" data-lightbox="example-set">
                             <span class="img">
                                 <img src="<?php echo e(asset('static/uploads'.'/'.$v->img)); ?>"/>
                             </span>
                             <span class="year">

                             </span>
                             <span class="tit">
                               <?php echo e($v->name); ?>

                             </span>

                           </a>
                       </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>

                </div>
            </div>
        </div>
        <div class="insrightnav">
          <a href="<?php echo e(route('product')); ?>">
              产品汇总
          </a>
          <a href="<?php echo e(route('device')); ?>">
              设备展示
          </a>
        </div>
        <script type="text/javascript">
            var hdnav = '1';
            $('.insrightnav>a:eq(' + hdnav + ')').addClass("cur");
        </script>
    </div>
</div>

<div id="backhome">
    <a href="/"><span><i></i>返回首页</span></a>
</div>
<?php echo $__env->make('home/foot', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>