
    <div id="i-foottop" class="clearfix wow fadeInUp">
       <div class="con">
           <div class="conbox">
             <div class="flogo">
                 <img src="<?php echo e(asset('static/home/img/logo.png')); ?>"/>
             </div>
               <div class="coninfo">
                   <p class="add">地址：中国 浙江省温州乐清市柳市新光工业区新光大道151号</p>
                   <p class="tel">电话：86 0577 61717666</p>
                   <p class="fax">传真：86 0577 62799218</p>
               </div>
               <div class="fcode">
                   <img src="<?php echo e(asset('static/home/img/wxcode.jpg')); ?>">
                   <img src="<?php echo e(asset('static/home/img/wxcode.jpg')); ?>">
               </div>
           </div>
       </div>
       <div class="fnav">
           <ul>
               <li>
                   <a href="<?php echo e(route('about')); ?>">关于我们</a>
                   <ul class="sub">
                       <li>
                           <a href="<?php echo e(route('about')); ?>">公司简介</a>
                       </li>
                       <li>
                           <a href="<?php echo e(route('culture')); ?>">企业文化</a>
                       </li>
                       <li>
                           <a href="<?php echo e(route('honor')); ?>">荣誉证书</a>
                       </li>
                   </ul>
               </li>
               <li>
                   <a href="pro.html">产品中心</a>
                   <ul class="sub">
                       <li>
                           <a href="<?php echo e(route('product')); ?>">产品汇总</a>
                       </li>
                       <li>
                           <a href="<?php echo e(route('device')); ?>">设备展示</a>
                       </li>
                   </ul>
               </li>
               <li>
                   <a href="<?php echo e(route('feedback')); ?>">服务支持</a>
                   <ul class="sub">
                       <li>
                           <a href="<?php echo e(route('feedback')); ?>">在线留言</a>
                       </li>
                       <li>
                           <a href="<?php echo e(route('order')); ?>">在线订单</a>
                       </li>
                   </ul>
               </li>
               <li>
                   <a href="<?php echo e(route('contact')); ?>">联系我们</a>
                   <ul class="sub">
                       <li>
                           <a href="<?php echo e(route('contact')); ?>">联系方式</a>
                       </li>
                       <li>
                           <a href="<?php echo e(route('map')); ?>">地图导航</a>
                       </li>
                   </ul>
               </li>
           </ul>
       </div>
       <div class="fsearch">
         <div class="fsearchbox">
             <div class="tit">
                 <span class="cn">搜索中心</span>
                   <span class="en">
                   SEARCH<br>
                   CENTER
                   </span>
             </div>
             <form action="<?php echo e(route('search')); ?>" method="post"  id="myForm" class="clearfix">
                 <input type="text" class="key" placeholder="请输入关键词.." value="<?php echo e(isset($keys) ? $keys : ''); ?>" name="keys">
                 <input type="submit" class="submit" value="">
                  <?php echo e(csrf_field()); ?>

             </form>
         </div>
       </div>
    </div>


<div id="i-footbot" class="clearfix wow fadeInUp">
    <div class="icp">
        COPYRIGHT © 浙江金安电气有限公司 ALL RIGHTS RESERVED  浙ICP备11111111号
    </div>
    <div class="botlink">
        <a href="feedback.html" class="first">在线留言</a>
        <a href="contact.html">联系我们</a>
    </div>

</div>
 <script type="text/javascript">
 $(function(){
   $.ajax({
       type: "GET",
       url: '<?php echo e(route('Statistics')); ?>',
       headers: {
           'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
       },
       error: function (request) {

           layer.msg('出错联系管理员');
       }
   });

 });
 </script>
