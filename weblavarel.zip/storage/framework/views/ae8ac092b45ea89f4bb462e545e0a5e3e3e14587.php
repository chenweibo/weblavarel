<?php $__env->startSection('title','在线订单'.'-'.$system['title']); ?>
<?php $__env->startSection('keywords', $system['keywords']); ?>
<?php $__env->startSection('description', $system['description']); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('home/header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<script type="text/javascript">
    var hdnav='4';
    $('.pcnavBar ul.pcnav>li:eq('+hdnav+')').addClass("on");
</script>
<script type="text/javascript">
 jQuery(".pcnavBar .pcnav").slide({ type:"menu",  titCell:".m", targetCell:".sub",effect:"slideDown", delayTime:500, triggerTime:0,returnDefault:true  });
</script>

<div class="nyslide" style="background:url(<?php echo e(asset('static/home/img/orderny.jpg')); ?>) no-repeat center top; background-size:cover;">
    <ul>
        <li class="ch wow fadeInLeft" data-wow-delay="0.3s">
            <span class="cn">在线订单</span>
            <span class="en text-uppercase">Online order</span>
        </li>
    </ul>
</div>

<!--inspage.start-->

<div id="inspage">
    <div class="inspagebox clearfix">

        <!--ipad.mobile-->
        <div class="mobinsrightnav clearfix ">
          <a href="<?php echo e(route('feedback')); ?>">
              在线留言
          </a>
          <a href="<?php echo e(route('order')); ?>">
              在线订单
          </a>
        </div>
        <script type="text/javascript">
            var hdnav='1';
            $('.mobinsrightnav>a:eq('+hdnav+')').addClass("cur");
        </script>
        <div class="insleft">
            <div class="title wow fadeInUp">
                <p class="cn">在线购买您需要的产品</p>
                <p class="en">Buy the products you need online</p>
            </div>
            <div class="insinfo">
                <div class="feedbackinfo clearfix wow fadeInUp">
                    <form  onsubmit="return gbookajax()" id="gbook" class="form" >
                        <div class="text1"><span>您的姓名：</span><input type="text" name="name" placeholder="请输入收货人的姓名" class="text"></div>
                        <div class="text1"><span>联系号码：</span><input type="text" name="telephone" placeholder="请输入收货人的座机或手机号码" class="text"></div>
                        <div class="text1"><span>收货地址：</span><input type="text" name="address" placeholder="请输入收货人的姓名" class="text"></div>
                        <div class="text1"><span>收货邮编：</span><input type="text" name="code" placeholder="请输入收货地的邮编" class="text"></div>
                        <div class="text2">
                            <span>留言内容：</span>

                            <textarea id="info" name="content" class="textarea" placeholder="请输入您所需要的产品名称、数量以及其他要求"></textarea>
                        </div>
                         <input type="hidden" name="title" value="新的在线订单">
                         <input type="hidden" name="time" value="<?php echo e($time); ?>">
                        <input type="submit"value="提交内容" class="submit">
                    </form>
                </div>
            </div>
        </div>
        <script type="text/javascript">
        function gbookajax() {
            var jz;
            var url = "<?php echo e(route('order')); ?>";
            $.ajax({
                type: "POST",
                url: url,
                data: $('#gbook').serialize(),
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                beforeSend: function () {
                    jz = layer.load(0, {shade: false}); //0代表加载的风格，支持0-2
                },
                error: function (request) {
                    layer.close(jz);
                    layer.msg('出错联系管理员');
                },
                success: function (data) {
                    //关闭加载层
                    layer.close(jz);
                    if (data.code == 1) {
                      layer.msg(data.msg);
                    } else {
                      layer.msg(data.msg);
                    }
                }
            });

            return false;
        }
        </script>
        <div class="insrightnav">
          <a href="<?php echo e(route('feedback')); ?>">
              在线留言
          </a>
          <a href="<?php echo e(route('order')); ?>">
              在线订单
          </a>
        </div>
        <script type="text/javascript">
            var hdnav='1';
            $('.insrightnav>a:eq('+hdnav+')').addClass("cur");
        </script>
    </div>
</div>

<div id="backhome">
    <a href="/"><span><i></i>返回首页</span></a>
</div>

<?php echo $__env->make('home/foot', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>