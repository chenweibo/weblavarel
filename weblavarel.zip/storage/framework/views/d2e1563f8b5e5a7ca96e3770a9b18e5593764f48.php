<?php $__env->startSection('title','关于我们'.'-'.$system['title']); ?>
<?php $__env->startSection('keywords', $system['keywords']); ?>
<?php $__env->startSection('description', $system['description']); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('home/header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<script type="text/javascript">
    var hdnav='0';
    $('.pcnavBar ul.pcnav>li:eq('+hdnav+')').addClass("on");
</script>
<script type="text/javascript">
 jQuery(".pcnavBar .pcnav").slide({ type:"menu",  titCell:".m", targetCell:".sub",effect:"slideDown", delayTime:500, triggerTime:0,returnDefault:true  });
</script>
<div class="nyslide" style="background:url(<?php echo e(asset('static/home/img/aboutny.jpg')); ?>) no-repeat center top; background-size:cover;">
    <ul>
        <li class="ch wow fadeInLeft" data-wow-delay="0.3s">
            <span class="cn">公司简介</span>
            <span class="en text-uppercase">Company Profile</span>
        </li>
    </ul>
</div>

<!--inspage.start-->

<div id="inspage">
     <div class="inspagebox clearfix">

         <!--ipad.mobile-->
         <div class="mobinsrightnav clearfix ">
           <a href="<?php echo e(route('about')); ?>">
               公司简介
           </a>
           <a href="<?php echo e(route('culture')); ?>">
               企业文化
           </a>
           <a href="<?php echo e(route('honor')); ?>">
               荣誉证书
           </a>
         </div>
         <script type="text/javascript">
             var hdnav='0';
             $('.mobinsrightnav>a:eq('+hdnav+')').addClass("cur");
         </script>
        <div class="insleft">
           <div class="title wow fadeInUp">
               <p class="cn">浙江金安电气有限公司</p>
               <p class="en">ZheJiang Jinan Electric Co., Ltd</p>
           </div>
            <div class="insinfo">
              <div class="aboutinfo clearfix">
                  <div class="part1 wow fadeInUp clearfix">
                  <div class="img">
                      <img src="<?php echo e(asset('static/home/img/insaboutimg.jpg')); ?>"/>
                  </div>
                  <div class="con1">
                      <p class="one">浙江金安电气有限公司创办于2001年，是正泰集团合作单位，正泰气动电磁铁生产厂家，中国重型机械工业协会传动部件专业委员会会员单位。我司现有40多家专业协作单位，专业生产经营气动元件，电磁铁、制动器等150多个系列，3000多种规格的各类产品。产品适用于冶金、机电、煤炭、建筑机械、运输、家电、轻工、机床、医疗等行业自动化生产设备的需要。公司创业历史悠久，生产经验丰富，技术力量雄厚，现有员工300余名，其中管理人员及专业技术人员、高级工程师占员工总人数的20%以上。我们坚持“科技创新，品质一流”的经营理念，近年来，先后投入巨资引进了各类精密的高科技检测设备，并成功的研制开发了多品种多系列多规格的产品。 
                      </p>
                      我司生产厂房占地面积12000平方米，拥有卓越的经营团队，良好的产品性能，严谨的质量管理体系。本着“和谐，务实，创新”的价值观，以“质量第一，厂兴我荣，厂衰我耻”的意识，建设公司质量经营、诚信经营的质量文化。在生产过程中，我们严格按照ISO9001国际质量管理体系规范运行，产品合格率达到了令人满意的标准。历年来被柳市镇人民政府评为明星企业。
                  </div>
                  </div>
                  <div class="part2 wow fadeInUp">
                      <div class="data">
                          <div class="member2 pull-left">
                              <p class="num"><i id="num02">2001</i><span>年</span></p>
                              <p class="sm">我司创办于</p>
                          </div>
                          <div class="member2 pull-left">
                              <p class="num"><i id="num02">150</i>+<span>系列</span></p>
                              <p class="sm">我司专业生产经营</p>
                          </div>
                          <div class="member3 pull-left">
                              <p class="num"><i id="num03">300</i>+<span>名</span></p>
                              <p class="sm">我司现有员工</p>
                          </div>
                          <div class="member4 pull-left">
                              <p class="num"><i id="num04">12000</i>+<span>平米</span></p>
                              <p class="sm">我司生产厂房占地面积</p>
                          </div>
                          <div class="clear" style="clear: both;"></div>
                      </div>
                  </div>
                  <div class="part3 wow fadeInUp">
                      <div class="title">
                          <p class="cn">追求更加辉煌的未来</p>
                          <p class="en">The pursuit of a more brilliant future</p>
                      </div>
                      <p>
                          我司依托正泰公司强大的营销队伍和遍布世界的营销网络，及国内1000多家销售公司和特约经销点，产品畅销国内外。我们不断创新，大力引进先进技术设备和优秀人才，努力将公司打造成基业长青的国内外知名企业。我们愿与海内外客商真诚合作，携手发展，共享繁荣与成功之喜悦，永无止境的追求更加辉煌的未来。
                      </p>
                  </div>
              </div>
            </div>
        </div>
         <div class="insrightnav">
             <a href="<?php echo e(route('about')); ?>">
                 公司简介
             </a>
             <a href="<?php echo e(route('culture')); ?>">
                 企业文化
             </a>
             <a href="<?php echo e(route('honor')); ?>">
                 荣誉证书
             </a>
         </div>
         <script type="text/javascript">
             var hdnav='0';
             $('.insrightnav>a:eq('+hdnav+')').addClass("cur");
         </script>
     </div>
</div>

<div id="backhome">
    <a href="/"><span><i></i>返回首页</span></a>
</div>

<!--inspage.end-->

<?php echo $__env->make('home/foot', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>