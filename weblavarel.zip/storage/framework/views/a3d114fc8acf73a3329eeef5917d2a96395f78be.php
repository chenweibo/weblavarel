<?php $__env->startSection('title','联系我们'.'-'.$system['title']); ?>
<?php $__env->startSection('keywords', $system['keywords']); ?>
<?php $__env->startSection('description', $system['description']); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('home/header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<script type="text/javascript">
    var hdnav='6';
    $('.pcnavBar ul.pcnav>li:eq('+hdnav+')').addClass("on");
</script>
<script type="text/javascript">
 jQuery(".pcnavBar .pcnav").slide({ type:"menu",  titCell:".m", targetCell:".sub",effect:"slideDown", delayTime:500, triggerTime:0,returnDefault:true  });
</script>


<div class="nyslide" style="background:url(<?php echo e(asset('static/home/img/contactny.jpg')); ?>) no-repeat center top; background-size:cover;">
    <ul>
        <li class="ch wow fadeInLeft" data-wow-delay="0.3s">
            <span class="cn">联系方式</span>
            <span class="en text-uppercase">Contact information</span>
        </li>
    </ul>
</div>

<!--inspage.start-->

<div id="inspage">
    <div class="inspagebox clearfix">

        <!--ipad.mobile-->
        <div class="mobinsrightnav clearfix ">
            <a href="<?php echo e(route('contact')); ?>">
                联系方式
            </a>
            <a href="<?php echo e(route('map')); ?>">
                地图导航
            </a>
        </div>
        <script type="text/javascript">
            var hdnav='0';
            $('.mobinsrightnav>a:eq('+hdnav+')').addClass("cur");
        </script>
        <div class="insleft">
            <div class="title wow fadeInUp">
                <p class="cn">您可按照下列方式联系我们</p>
                <p class="en">You can contact us as follows</p>
            </div>
            <div class="insinfo">
               <div class="contactinfo clearfix wow fadeInUp">
                   <div class="part1 clearfix">
                       <div class="add"><span>地址：</span>中国 浙江省温州乐清市柳市新光工业区新光大道151号</div>
                       <div class="add"><span>电话：</span>86-0577-61717666</div>
                       <div class="add"><span>邮编：</span>325604</div>
                       <div class="add"><span>传真：</span>86-0577-62799218</div>
                   </div>
                   <div class="part2 clearfix">
                       <div class="ewm">
                           <img src="<?php echo e(asset('static/home/img/ewm.jpg')); ?>"/>
                       </div>
                       <div class="care">
                           关注微信公众号
                       </div>
                   </div>
               </div>
            </div>
        </div>
        <div class="insrightnav">
          <a href="<?php echo e(route('contact')); ?>">
              联系方式
          </a>
          <a href="<?php echo e(route('map')); ?>">
              地图导航
          </a>
        </div>
        <script type="text/javascript">
            var hdnav='0';
            $('.insrightnav>a:eq('+hdnav+')').addClass("cur");
        </script>
    </div>
</div>

<div id="backhome">
    <a href="/"><span><i></i>返回首页</span></a>
</div>

<?php echo $__env->make('home/foot', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>