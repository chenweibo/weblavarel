<?php $__env->startSection('title', $catename->name.'-'.$system['title']); ?>
<?php $__env->startSection('keywords', $system['keywords']); ?>
<?php $__env->startSection('description', $system['description']); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('home/header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<script type="text/javascript">
    var hdnav = '1';
    $('.pcnavBar ul.pcnav>li:eq(' + hdnav + ')').addClass("on");
</script>
  <script type="text/javascript">
   jQuery(".pcnavBar .pcnav").slide({ type:"menu",  titCell:".m", targetCell:".sub",effect:"slideDown", delayTime:500, triggerTime:0,returnDefault:true  });
</script>
<div class="nyslide" style="background:url(<?php echo e(asset('static/home/img/prony.jpg')); ?>) no-repeat center top; background-size:cover;">
    <ul>
        <li class="ch wow fadeInLeft" data-wow-delay="0.3s">
            <span class="cn">产品汇总</span>
            <span class="en text-uppercase">Product summary</span>
        </li>
    </ul>
</div>

<!--inspage.start-->

<div id="inspage">
    <div class="inspagebox clearfix">

        <!--ipad.mobile-->
        <div class="mobinsrightnav clearfix ">
          <a href="<?php echo e(route('product')); ?>">
              产品汇总
          </a>
          <a href="<?php echo e(route('device')); ?>">
              设备展示
          </a>
        </div>
        <script type="text/javascript">
            var hdnav = '0';
            $('.mobinsrightnav>a:eq(' + hdnav + ')').addClass("cur");
        </script>
        <div class="insleft">
            <div class="title wow fadeInUp">
                <p class="cn">专业生产经营气动元件，电磁铁、制动器等150多个系列</p>
                <p class="en">Professional production and operation of pneumatic components...</p>
            </div>
            <div class="insinfo">
                <div class="proinfo clearfix wow fadeInUp">
                  <ul class="pronav clearfix">
                     <?php $__currentLoopData = $cate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <li class="m" >
                          <a <?php if($v['id'] == $nn->id): ?>
                           class="cur"
                          <?php endif; ?> href="javascript:void(0);"><?php echo e($v['name']); ?></a>
                          <?php if(!empty($v['children'])): ?>
                            <ul class="prosub">
                              <?php $__currentLoopData = $v['children']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e($vo['rewrite']); ?>"><?php echo e($vo['name']); ?></a></li>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                          <?php endif; ?>
                      </li>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </ul>
                    <script type="text/javascript">
                        jQuery(".pronav").slide({
                            type: "menu",
                            titCell: ".m",
                            trigger:"click",
                            targetCell: "ul.prosub",
                            effect: "slideDown",
                            delayTime: 500,
                            triggerTime: 0,
                            returnDefault: true
                        });
                    </script>

                    <ul class="pro2">
                       <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <span class="bg"><a href="<?php echo e(asset('static/uploads'.'/'.$v->down)); ?>" class="pdf" target="_blank"><img src="<?php echo e(asset('static/home/img/pdf.png')); ?>"/></a></span>
                            <a href="<?php echo e(route('productview',$v->rewrite)); ?>" >
                                <span class="img">
                                    <img src="<?php echo e(asset('static/uploads'.'/'.$v->img)); ?>"/>
                                </span>
                                <span class="name">
                                   <?php echo e($v->name); ?>

                                </span>
                            </a>
                        </li>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </ul>
                </div>
            </div>
        </div>
        <div class="insrightnav">
          <a href="<?php echo e(route('product')); ?>">
              产品汇总
          </a>
          <a href="<?php echo e(route('device')); ?>">
              设备展示
          </a>
        </div>
        <script type="text/javascript">
            var hdnav = '0';
            $('.insrightnav>a:eq(' + hdnav + ')').addClass("cur");
        </script>
    </div>
</div>

<div id="backhome">
    <a href="/"><span><i></i>返回首页</span></a>
</div>

<?php echo $__env->make('home/foot', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>