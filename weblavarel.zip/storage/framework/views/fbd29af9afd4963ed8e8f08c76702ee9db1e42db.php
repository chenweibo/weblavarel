<?php $__env->startSection('title', '荣誉证书'.'-'.$system['title']); ?>
<?php $__env->startSection('keywords', $system['keywords']); ?>
<?php $__env->startSection('description', $system['description']); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('home/header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<script type="text/javascript">
    var hdnav='0';
    $('.pcnavBar ul.pcnav>li:eq('+hdnav+')').addClass("on");
</script>

<div class="nyslide" style="background:url(<?php echo e(asset('static/home/img/honorny.jpg')); ?>) no-repeat center top; background-size:cover;">
    <ul>
        <li class="ch wow fadeInLeft" data-wow-delay="0.3s">
            <span class="cn">荣誉证书</span>
            <span class="en text-uppercase">honor certificate</span>
        </li>
    </ul>
</div>

<!--inspage.start-->

<div id="inspage">
    <div class="inspagebox clearfix">

        <!--ipad.mobile-->
        <div class="mobinsrightnav clearfix ">
          <a href="<?php echo e(route('about')); ?>">
              公司简介
          </a>
          <a href="<?php echo e(route('culture')); ?>">
              企业文化
          </a>
          <a href="<?php echo e(route('honor')); ?>">
              荣誉证书
          </a>
        </div>
        <script type="text/javascript">
            var hdnav='2';
            $('.mobinsrightnav>a:eq('+hdnav+')').addClass("cur");
        </script>
        <div class="insleft">
            <div class="title wow fadeInUp">
                <p class="cn">企业荣誉是品牌口碑的重要表现形式</p>
                <p class="en">Corporate honor is an important form of brand reputation</p>
            </div>
            <div class="insinfo">
                <div class="honorinfo clearfix wow fadeInUp">
                    <link rel="stylesheet" href="<?php echo e(asset('static/home/css/lightbox.css')); ?>">
                    <script type="text/javascript" src="<?php echo e(asset('static/home/js/base.js')); ?>"></script>
                    <script type="text/javascript" src="<?php echo e(asset('static/home/js/jquery.lightbox.js')); ?>"></script>
                   <ul class="honor">

                      <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <li>
                           <a href="<?php echo e(asset('static/uploads'.'/'.$v->img)); ?>" data-lightbox="example-set">
                             <span class="img">
                                 <img src="<?php echo e(asset('static/uploads'.'/'.$v->img)); ?>"/>
                             </span>
                             <span class="year">

                             </span>
                             <span class="tit">
                               <?php echo e($v->name); ?>

                             </span>

                           </a>
                       </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   </ul>

                </div>
            </div>
        </div>
        <div class="insrightnav">
          <a href="<?php echo e(route('about')); ?>">
              公司简介
          </a>
          <a href="<?php echo e(route('culture')); ?>">
              企业文化
          </a>
          <a href="<?php echo e(route('honor')); ?>">
              荣誉证书
          </a>
        </div>
        <script type="text/javascript">
            var hdnav='2';
            $('.insrightnav>a:eq('+hdnav+')').addClass("cur");
        </script>
    </div>
</div>

<div id="backhome">
    <a href="/"><span><i></i>返回首页</span></a>
</div>


<?php echo $__env->make('home/foot', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>