<?php $__env->startSection('title', $system['title']); ?>
<?php $__env->startSection('keywords', $system['keywords']); ?>
<?php $__env->startSection('description', $system['description']); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('home/header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<script type="text/javascript">
    var hdnav = '0';
    $('.pcnavBar ul.pcnav>li:eq(' + hdnav + ')').addClass("on");
</script>
  <script type="text/javascript">
   jQuery(".pcnavBar .pcnav").slide({ type:"menu",  titCell:".m", targetCell:".sub",effect:"slideDown", delayTime:500, triggerTime:0,returnDefault:true  });
</script>

    <div id="myCarousel" class="carousel slide">
        <div class="abouticon visible-lg visible-md  visible-sm">
            <div class="container">
            </div>
        </div>
        <ol class="carousel-indicators">
            <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
            <li data-target="#myCarousel" data-slide-to="1"></li>
            <li data-target="#myCarousel" data-slide-to="2"></li>
        </ol>
        <div class="carousel-inner">
            <div class="item active">
                <img src="<?php echo e(asset('static/home/img/slide1.jpg')); ?>" alt="First slide">
            </div>
            <div class="item">
                <img src="<?php echo e(asset('static/home/img/slide1.jpg')); ?>" alt="Second slide">
            </div>
            <div class="item">
                <img src="<?php echo e(asset('static/home/img/slide1.jpg')); ?>" alt="Third slide">
            </div>
        </div>
    </div>
    <script>
        $(function(){
            $('#myCarousel').carousel('cycle');
            $('#identifier').carousel({
                interval: 500});
        });
    </script>

<!--Slide.end-->

<!--Three.start-->

    <div id="i-three" class="clearfix container2">
     <div class="i-three-box1 wow fadeInUp">
         <a href="">
             <span class="threeimg">
             </span>
             <div>
                 <div class="three-tit text-left clearfix">
                     <span class="cn">行业龙头</span>
                     <!--<span class="line"></span>-->
                     <span class="en">
                         <p>Industry</p>
                         <p class="mtop">leader</p>
                     </span>
                 </div>
                 <div class="three-info">浙江金安电气有限公司创办于2001年，是正泰集团合作单位，正泰气动电磁铁生产厂家..</div>
             </div>
         </a>
     </div>
     <div class="i-three-box2 wow fadeInUp">
        <a href="">
         <span class="threeimg">
         </span>
            <div>
                <div class="three-tit text-left clearfix">
                    <span class="cn">精工细作</span>
                    <!--<span class="line"></span>-->
                    <span class="en">
                     <p>Serious</p>
                     <p class="mtop">work</p>
                 </span>
                </div>
                <div class="three-info">我司生产厂房占地面12000平方米，拥有卓越的经营团队，良好的产品性能，严谨的质量..</div>
            </div>
        </a>
     </div>
     <div class="i-three-box3 wow fadeInUp">
            <a href="">
                <span class="threeimg"></span>
                <div>
                    <div class="three-tit text-left clearfix">
                        <span class="cn">周全服务</span>
                        <!--<span class="line"></span>-->
                        <span class="en">
                         <p>SERVICE</p>
                         <p class="mtop">FULL</p>
                     </span>
                    </div>
                    <div class="three-info">我司依托正泰公司强大的营销队伍和遍布世界的营销网络，及国内1000多家销售公司和..</div>
                </div>
            </a>
     </div>
    </div>

<!--Three.end-->

<!--About.start-->

    <div id="i-about" class="clearfix container2 wow fadeInUp">
        <div class="aboutimg hidden-xs">

        </div>
       <div class="aboutimg2 visible-xs">
           <img src="<?php echo e(asset('static/home/img/iaboutbg.jpg')); ?>"/>
       </div>
       <div class="aboutinfo">
         <div class="aboutinfo-tit">
           <span class="cn">公司简介</span>
           <span class="en">
               Company<br/>
               Profile
           </span>
         </div>
           <p class="info">
               浙江金安电气有限公司创办于2001年，是正泰集团合作单位，正泰气动电磁铁生产厂家，中国重型机械工业协会传动部件专业委员会会员单位。
               我司现有40多家专业协作单位，专业生产经营气动元件，电磁铁、制动器等150多个系列，3000多种规格的各类产品。
               产品适用于冶金、机电、煤炭、建筑机械、运输、家电、轻工、机床、医疗等行业自动化生产设备的需要。公司创业历史悠久，生产经验丰富，技术力量雄厚，现有员工300余名，其中管理人员及专业技术人员、高级工程师占员工总人数的20%以上。
               我们坚持“科技创新，品质一流”的经营理念，近年来，先后投入巨资引进了各类精密的高科技检测设备，并成功的研制开发了多品种多系列多规格的产品...
           </p>
           <a href="<?php echo e(route('about')); ?>" class="aboutmore">查看详情<i></i></a>
       </div>
    </div>

<!--About.end-->

<!--Product.start-->

    <div id="i-pro" class="clearfix wow fadeInTop">
       <div class="i-procate">
           <div class="top clearfix">
            <div class="tit">
               <span class="cn">产品中心</span>
               <span class="en">
               PRODUCT<br>
               CENTER
               </span>
           </div>
            <a href="<?php echo e(route('product')); ?>" class="more">查看详情<i></i></a>
           </div>

           <!--PS:大类链接做死-->

           <ul class="pros clearfix">
               <li>
                   <a href="">
                     <span class="img">
                         <img src="<?php echo e(asset('static/home/img/p1.png')); ?>"/>
                     </span>
                       <span class="name">
                           气动执行元件
                       </span>
                       <span class="more">MORE+</span>
                   </a>
               </li>
               <li>
                   <a href="">
                     <span class="img">
                         <img src="<?php echo e(asset('static/home/img/p2.png')); ?>"/>
                     </span>
                       <span class="name">
                           气动控制元件
                       </span>
                       <span class="more">MORE+</span>
                   </a>
               </li>
               <li>
                   <a href="">
                     <span class="img">
                         <img src="<?php echo e(asset('static/home/img/p3.png')); ?>"/>
                     </span>
                       <span class="name">
                           气源处理元件
                       </span>
                       <span class="more">MORE+</span>
                   </a>
               </li>
               <li>
                   <a href="">
                     <span class="img">
                         <img src="<?php echo e(asset('static/home/img/p4.png')); ?>"/>
                     </span>
                       <span class="name">
                           气动辅助元件
                       </span>
                       <span class="more">MORE+</span>
                   </a>
               </li>
               <li>
                   <a href="">
                     <span class="img">
                         <img src="<?php echo e(asset('static/home/img/p5.png')); ?>"/>
                     </span>
                       <span class="name">
                           电磁铁
                       </span>
                       <span class="more">MORE+</span>
                   </a>
               </li>
               <li>
                   <a href="">
                     <span class="img">
                         <img src="<?php echo e(asset('static/home/img/p6.png')); ?>"/>
                     </span>
                       <span class="name">
                           制动器
                       </span>
                       <span class="more">MORE+</span>
                   </a>
               </li>
           </ul>
       </div>
    </div>

<!--Product.end-->

<!--News.start-->

    <div id="i-news" class="clearfix wow fadeInUp">
        <div class="newspart">
            <div class="news">
              <div class="top clearfix">
                  <div class="tit">
                      <span class="cn">新闻资讯</span>
                      <span class="en">
                       NEWS AND<br>
                       INFORMATION
                       </span>
                  </div>
                  <a href="<?php echo e(route('news')); ?>" class="more">查看详情<i></i></a>
              </div>
                <div class="bd">
                    <ul class="clearfix">
                       <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <li class="clearfix">
                            <a href="route('newsView',$v->id)">
                                <span class="tit"><?php echo e($v->name); ?></span>
                                <span class="date"><?php echo e($v->time); ?></span>
                            </a>
                        </li>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </ul>
                </div>
                <div class="hd clearfix"><ul></ul></div>
            </div>
            <script type="text/javascript">
                jQuery(".news").slide({titCell:".hd ul",mainCell:".bd ul",autoPage:true,effect:"top",autoPlay:true,vis:3,scroll:3});
            </script>
        </div>
        <div class="imgright">
            <img src="<?php echo e(asset('static/home/img/inews1.jpg')); ?>" alt="">
            <img src="<?php echo e(asset('static/home/img/inews2.jpg')); ?>" alt="">
            <img src="<?php echo e(asset('static/home/img/inews3.jpg')); ?>" alt="">
            <img src="<?php echo e(asset('static/home/img/inews4.jpg')); ?>" alt="">
        </div>
    </div>


<?php echo $__env->make('home/foot', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>






<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>