 <?php $__env->startSection('content'); ?>

    <div class="wrapper wrapper-content animated fadeInRight">

        <div class="ibox float-e-margins">
            <div class="ibox-title">
                <h5>图片管理</h5>

                <div class="ibox-tools">
                    <a class="collapse-link">
                        <i class="fa fa-chevron-up"></i>
                    </a>
                    <a class="dropdown-toggle" data-toggle="dropdown" href="form_basic.html#">
                        <i class="fa fa-wrench"></i>
                    </a>
                    <a class="close-link">
                        <i class="fa fa-times"></i>
                    </a>
                </div>
            </div>
            <div class="ibox-content">
                <?php if(!empty(session('error'))): ?>
                    <div class="alert alert-danger">
                        <?php echo e(session('error')); ?>

                    </div>
                <?php endif; ?>

                <a href="<?php echo e(route('ImageCreate',['pid'=>$id])); ?>" class="btn btn-primary">添加</a>
                <a href="#" onclick="javascript:Del(arr,'<?php echo e(route("ImageMoreDelete")); ?>')"
                   class="btn btn-primary">批量删除</a>
                <div class="btn-group">
                    <button data-toggle="dropdown" class="btn btn-primary dropdown-toggle" aria-expanded="false">更多操作
                        <span class="caret"></span>
                    </button>
                    <ul class="dropdown-menu">
                        <li><a href="#" onclick="movefile(arr,4)">移动</a>
                        </li>
                        <li><a href="#" onclick="copyfile(arr,4)">复制</a>
                        </li>
                    </ul>
                </div>

                <div class="admin_search row" style=" height:35px; float:right">
                    <form class="navbar-form navbar-left zz" action="<?php echo e(route('Image')); ?>" method="get" role="search">
                        <div class="form-group">
                            <select class="form-control" name="path" required>

                                <option value="0">全部分类</option>
                                <?php $__currentLoopData = $cate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option <?php if($id ==$v['id'] ): ?> selected="select"
                                            <?php endif; ?> value="<?php echo e($v['id']); ?>"><?php echo e($v['html']); ?><?php echo e($v['name']); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="input-group">
                            <input id="keys" type="text" value="<?php echo e($keys); ?>" class="form-control" name="keys">
                        </div>
                        <button type="submit" style="margin-bottom:0" class="btn btn-primary">搜索</button>
                    </form>
                </div>

                <div class="clearfix" style="clear:both"></div>
                <div class="layui-form">
                    <div class="table-min">
                        <table class="layui-table">
                            <colgroup>
                                <col width="50">
                                <col width="50">
                                <col>
                                <col>
                                <col width="80">
                                <col width="80">
                                <col width="100">
                                <col width="100">
                                <col width="200">
                            </colgroup>
                            <thead>
                            <tr>
                                <th><input name="" lay-skin="primary" lay-filter="allChoose" type="checkbox"></th>
                                <th>id</th>
                                <th>名称</th>
                                <th>分类</th>
                                <th>排序</th>
                                <th>缩略图</th>
                                <th>状态</th>
                                <th>推荐</th>
                                <th>操作</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><input data-id="<?php echo e($v->id); ?>" name="ck" lay-skin="primary" lay-filter="son"
                                               type="checkbox"></td>
                                    <td><?php echo e($v->id); ?></td>
                                    <td><?php echo e($v->name); ?></td>
                                    <td><?php echo e($v->colums); ?></td>
                                    <td data-id="<?php echo e($v->id); ?>"
                                        onclick="sortAjax(event,'<?php echo e(route("ajaxSort")); ?>','content')"><?php echo e($v->sort); ?></td>
                                    <td><?php if($v->img == null): ?>
                                            <img title="点击放大" class="iconmig"
                                                 onclick="imgicon('<?php echo e(asset('static/admin/images/img.png')); ?>')"
                                                 src="<?php echo e(asset('static/admin/images/img.png')); ?>" alt="">
                                        <?php else: ?>
                                            <img title="点击放大" class="iconmig"
                                                 onclick="imgicon('<?php echo e(asset('static/uploads')); ?>/<?php echo e($v->img); ?>')"
                                                 src="<?php echo e(asset('static/uploads')); ?>/<?php echo e($v->img); ?>" alt="">
                                        <?php endif; ?></td>
                                    <td>
                                        <input type="checkbox" data-tid="<?php echo e($v->id); ?>" <?php if($v->show == 1): ?>    checked=""
                                               <?php endif; ?>  lay-skin="switch" lay-filter="show" lay-text="ON|OFF">
                                    </td>
                                    <td>
                                        <input type="checkbox" data-tid="<?php echo e($v->id); ?>"
                                               <?php if($v->recommend == 1): ?>    checked="" <?php endif; ?>  lay-skin="switch"
                                               lay-filter="recommend" lay-text="ON|OFF">
                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('ImageEdit',['id'=>$v->id])); ?>"
                                           class="layui-btn  layui-btn-small">编辑</a>
                                        <a href="javascript:Del(<?php echo e($v->id); ?>,'<?php echo e(route("ImageDelete")); ?>')"
                                           class="layui-btn layui-btn-danger layui-btn-small dc">删除</a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>

                </div>

                <?php echo e($list->appends(['path'=>$id,'keys'=>$keys])->links()); ?>

            </div>


            <script src="<?php echo e(asset('static/admin/js/content.min.js?v=1.0.0')); ?>"></script>
            <script src="<?php echo e(asset('static/admin/js/plugins/validate/jquery.validate.min.js')); ?>"></script>
            <script src="<?php echo e(asset('static/admin/js/plugins/validate/messages_zh.min.js')); ?>"></script>
            <script src="<?php echo e(asset('static/admin/js/plugins/sweetalert/sweetalert.min.js')); ?>"></script>
            <script src="<?php echo e(asset('static/admin/css/layui/layui.js')); ?>"></script>
            <script src="<?php echo e(asset('static/admin/js/plugins/layer/layer.min.js')); ?>"></script>
            <script src="<?php echo e(asset('static/admin/js/other.js')); ?>"></script>

            <script>
                var arr = [];
                layui.use('form', function () {
                    var $ = layui.jquery,
                        form = layui.form();
                    //全选
                    form.on('checkbox(allChoose)', function (data) {

                        var child = $(data.elem).parents('table').find('tbody td input[name="ck"]');
                        child.each(function (index, item) {
                            item.checked = data.elem.checked;
                        });
                        if (data.elem.checked == false) {
                            arr = [];
                        } else {
                            child.each(function () {
                                arr.push($(this).data('id'));
                            });
                        }
                        form.render('checkbox');
                        //  console.log(arr);
                    });

                    form.on('checkbox(son)', function (data) {
                        if (data.elem.checked == false) {
                            arr.splice($.inArray($(data.elem).data('id'), arr), 1);
                        }
                        else {
                            arr.push($(data.elem).data('id'));
                        }
                        //     console.log(arr);

                    });
                    form.on('switch(show)', function (data) {
                        var id = this.attributes['data-tid'].nodeValue;
                        var state = this.checked ? '1' : '0';
                        var url = "<?php echo e(route('ajaxState')); ?>";
                        var type = "content_show";
                        stateAjax(id, state, url, type)
                    });

                    form.on('switch(recommend)', function (data) {
                        var id = this.attributes['data-tid'].nodeValue;
                        var state = this.checked ? '1' : '0';
                        var url = "<?php echo e(route('ajaxState')); ?>";
                        var type = "content_recommend";
                        stateAjax(id, state, url, type)
                    });
                });


            </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>