<div id="i-head-fix">
  <div id="i-head">
    <!--<div class="container">-->

      <!--PCNav.start-->

      <div class="i-header clearfix visible-md visible-lg">
        <a href="/" class="logo pull-left">
          <img src="<?php echo e(asset('static/home/img/logo.png')); ?>">
        </a>
        <div class="pcnavBar pull-left">
            <ul class="pcnav clearfix text-right">
                <li class="m first">
                    <a href="<?php echo e(route('about')); ?>">关于我们</a>
                    <div class="sub">
                      <div class="sub-about">
                        <span class="sub-about-l pull-left">
                            <div class="sub-tit text-left">
                               公司简介
                            </div>
                            <p class="sub-about-info text-left">
                              浙江金安电气有限公司创办于2001年，是正泰集团合作单位，正泰气动电磁铁生产厂家，中国重型机械工业协会传动部件专业委员会会员单位...
                            </p>
                            <a href="<?php echo e(route('about')); ?>" class="more">了解详情</a>
                        </span>
                        <span class="sub-about-r pull-right">
                            <span class="sub-about-r-hon">
                            <div class="sub-tit text-left">
                               荣誉证书
                            </div>
                            <a href="<?php echo e(route('honor')); ?>" class="sub-img">
                            <img src="<?php echo e(asset('static/home/img/subhon.png')); ?>"/>
                            </a>
                            </span>
                            <span class="sub-about-r-cul pull-left">
                            <div class="sub-tit text-left">
                               企业文化
                            </div>
                            <a href="<?php echo e(route('culture')); ?>" class="sub-img">
                            <img src="<?php echo e(asset('static/home/img/subcul.png')); ?>"/>
                            </a>
                            </span>
                        </span>
                      </div>
                    </div>
                </li>
                <li class="m">
                    <a href="<?php echo e(route('product')); ?>">产品中心</a>
                    <div class="sub">
                        <div class="sub-pro">
                        <span class="sub-pro-l pull-left">
                            <div class="sub-tit text-left">
                               产品中心
                            </div>
                            <ul class="pro text-left">

                                <li><i></i><a href="pro2.html">气动执行元件</a></li>
                                <li><i></i><a href="pro2.html">气动执行元件</a></li>
                                <li><i></i><a href="pro2.html">气动执行元件</a></li>
                                <li><i></i><a href="pro2.html">气动执行元件</a></li>
                                <li><i></i><a href="pro2.html">气动执行元件</a></li>
                                <li><i></i><a href="pro2.html">气动执行元件</a></li>

                            </ul>
                            <a href="<?php echo e(route('product')); ?>" class="more">了解详情</a>
                        </span>
                        <span class="sub-pro-r pull-right">
                            <span class="sub-pro-r-equ">
                            <div class="sub-tit text-left">
                               设备展示
                            </div>
                            <a href="<?php echo e(route('device')); ?>" class="sub-img">
                            <img src="<?php echo e(asset('static/home/img/subequ.png')); ?>"/>
                            </a>
                            </span>
                        </span>
                        </div>
                    </div>
                </li>
                <li class="m">
                    <a href="<?php echo e(route('news')); ?>">新闻资讯</a>
                </li>
                <li class="m">
                    <a href="<?php echo e(route('download')); ?>">下载中心</a>
                </li>
                <li class="m">
                    <a href="<?php echo e(route('feedback')); ?>">服务支持</a>
                    <div class="sub">
                        <div class="sub-ser">
                        <span class="sub-ser-l pull-left">
                            <span class="sub-ser-l-feed">
                            <div class="sub-tit text-left">
                               在线订单
                            </div>
                            <a href="<?php echo e(route('order')); ?>" class="sub-img">
                            <img src="<?php echo e(asset('static/home/img/suborder.png')); ?>"/>
                            </a>
                            </span>
                            <span class="sub-ser-l-order pull-left">
                            <div class="sub-tit text-left">
                               在线留言
                            </div>
                            <a href="<?php echo e(route('feedback')); ?>" class="sub-img">
                            <img src="<?php echo e(asset('static/home/img/subfeed.png')); ?>"/>
                            </a>
                            </span>
                        </span>
                        </div>
                    </div>
                </li>
                <li class="m">
                    <a href="http://www.yqrc.com/show_company.asp?company_id=11637&vcod=yqrcod" target="_blank">人才招聘</a>
                </li>
                <li class="m last">
                    <a href="<?php echo e(route('contact')); ?>">联系我们</a>
                    <div class="sub">
                        <div class="sub-cont">
                        <span class="sub-cont-l pull-left">
                            <div class="sub-tit text-left">
                               联系方式
                            </div>
                            <div class="sub-cont-info text-left">
                               <p class="cont"><i></i>地址：中国 浙江省温州乐清市柳市新光工业区新光大道151号</p>
                               <p class="cont"><i></i>邮编：325604</p>
                               <p class="cont"><i></i>电话：86 0577 61717666</p>
                               <p class="cont"><i></i>传真：86 0577 62799218</p>
                            </div>
                        </span>
                            <span class="sub-cont-r pull-right">
                            <span class="sub-cont-r-map pull-left">
                            <div class="sub-tit text-left">
                               地图导航
                            </div>
                            <a href="<?php echo e(route('map')); ?>" class="sub-img">
                            <img src="<?php echo e(asset('static/home/img/submap.png')); ?>"/>
                            </a>
                            </span>
                        </span>
                        </div>
                    </div>
                </li>
            </ul>
        </div>

          <div class="login-lang pull-right">
              <?php if(session('memberusername')): ?>
                   <a href="<?php echo e(route('userloginout')); ?>"class="pull-left">登出</a>
                <?php else: ?>
                 <a href="javascript:;"class="login_link theme-login pull-left"><i class="pull-left"></i></a>
              <?php endif; ?>

              <div class="theme-popover">
                  <div class="theme-poptit">
                      <a href="javascript:;" title="关闭" class="close">×</a>
                      <h3>会员登陆</h3>
                  </div>
                  <div class="theme-popbod dform">
                      <form class="theme-signin" name="loginform" id="userform">
                          <ul>
                              <li><strong>用户名：</strong><input type="text" class="form-control" name="username" id="username" placeholder="请输入用户名"></li>
                              <li><strong>密码：</strong><input type="password" class="form-control" name="password" id="password" placeholder="请输入密码"></li>
                              <li>
                              <button class="btn btn-primary pull-left" type="button" id="submit"name="submit">登陆</button>
                              </li>
                          </ul>
                      </form>
                  </div>
              </div>

              <div class="theme-popover-mask"></div>
              <div class="line1 pull-left"></div>
              <div class="lang pull-left m">
                  <a href="javascript:;" class="on"><img src="<?php echo e(asset('static/home/img/shop.png')); ?>"><i class="arrow"></i></a>
                  <ul class="langnav">
                      <li><a href="" target="_blank">天猫</a></li>
                      <li><a href="" target="_blank">阿里巴巴</a></li>
                  </ul>
              </div>
              <div class="line1 pull-left"></div>
              <div class="lang pull-left m">
                  <a href="javascript:;" class="on"><img src="<?php echo e(asset('static/home/img/country_icon.png')); ?>"><i class="arrow"></i></a>
                  <ul class="langnav">
                      <li><a href="" target="_blank">中文</a></li>
                      <li><a href="" target="_blank">English</a></li>
                  </ul>
              </div>
          </div>
          <script type="text/javascript">
              jQuery(".login-lang").slide({ type:"menu",  titCell:".m", targetCell:"ul.langnav",effect:"slideDown", delayTime:500, triggerTime:0,returnDefault:true  });
          </script>
          <script>
              jQuery(document).ready(function($) {
                  $('.theme-login').click(function(){
                      $('.theme-popover-mask').fadeIn(100);
                      $('.theme-popover').slideDown(200);
                  })
                  $('.theme-poptit .close').click(function(){
                      $('.theme-popover-mask').fadeOut(100);
                      $('.theme-popover').slideUp(200);
                  })

              })
          </script>
          <script>
              $(function (){
                  $('#submit').click(function () {
                      var $usernameVal = $.trim($('#username').val());
                      var $passwordVal = $.trim($('#password').val());
                      if($usernameVal=='')
                      {
                          layer.msg('用户名不能为空', {icon: 5});
                          return false;
                      }
                      if($passwordVal=='')
                      {
                          layer.msg('密码不能为空', {icon: 5});
                          return false;
                      }
                      else {
                        var url = "<?php echo e(route('userlogin')); ?>";
                        $.ajax({
                            type: "POST",
                            url: url,
                            data: $('#userform').serialize(),
                            headers: {
                                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                            },
                            beforeSend: function () {
                                jz = layer.load(0, {shade: false}); //0代表加载的风格，支持0-2
                            },
                            error: function (request) {
                                layer.close(jz);
                                layer.msg('出错联系管理员');
                            },
                            success: function (data) {
                                //关闭加载层
                                layer.close(jz);
                                if (data.code == 1) {
                                  $('.close').click();
                                  $('.login_link').remove();
                                  $('.login-lang').prepend(' <a href="<?php echo e(route('userloginout')); ?>"class="pull-left">登出</a>');
                                  layer.msg('登录成功');
                                } else {
                                  layer.msg(data.msg);
                                }
                            }
                        });
                      }
                  });
              });
          </script>
      </div>

      <!--PCNav.end-->

      <!--MobNav.start-->

      <nav class="navbar navbar-default visible-xs visible-sm navbar-box" role="navigation">
          <div class="container-fluid">
              <div class="navbar-header">
                  <button type="button" class="navbar-toggle" data-toggle="collapse"
                          data-target="#example-navbar-collapse">
                      <span class="sr-only">切换导航</span>
                      <span class="icon-bar"></span>
                      <span class="icon-bar"></span>
                      <span class="icon-bar"></span>
                  </button>
                  <a class="navbar-brand" href=""><img src="<?php echo e(asset('static/home/img/logo.png')); ?>" class="brand-img"></a>
                  <div class="login-lang pull-left visible-xs">
                      <!--<a href="" class="login_link pull-left"><i class="pull-left"></i></a>-->
                      <!--<div class="line1 pull-left"></div>-->
                      <div class="lang pull-left m">
                          <!--<a href="javascript:;" class="on"><img src="img/country_icon.png"><i class="arrow"></i></a>-->
                          <ul class="langnav2">
                              <li><a href="" target="_blank">中文</a></li>
                              <li><a href="" target="_blank">English</a></li>
                          </ul>
                      </div>
                  </div>
              </div>
              <div class="collapse navbar-collapse" id="example-navbar-collapse">
                  <ul class="nav navbar-nav text-center ">
                      <li class="dropdown">
                          <a href="" class="dropdown-toggle" data-toggle="dropdown">
                              关于我们
                          </a>
                          <ul class="dropdown-menu ">
                              <li><a href="about.html">公司简介</a></li>
                              <li><a href="culture.html">企业文化</a></li>
                              <li><a href="honor.html">荣誉证书</a></li>
                          </ul>
                      </li>
                      <li class="dropdown">
                          <a href="pro.html" class="dropdown-toggle" data-toggle="dropdown">
                              产品中心
                          </a>
                          <ul class="dropdown-menu">
                              <li><a href="pro.html">产品汇总</a></li>
                              <li><a href="device.html">设备展示</a></li>
                          </ul>
                      </li>
                      <li class="dropdown">
                          <a href="news.html" class="dropdown-toggle" data-toggle="dropdown">
                              新闻资讯
                          </a>
                       </li>
                      <li class="dropdown">
                          <a href="download.html" class="dropdown-toggle" data-toggle="dropdown">
                              下载中心
                          </a>
                      </li>
                      <li class="dropdown">
                          <a href="feedback.html" class="dropdown-toggle" data-toggle="dropdown">
                              服务支持
                          </a>
                          <ul class="dropdown-menu">
                              <li><a href="feedback.html">在线留言</a></li>
                              <li><a href="order.html">在线订单</a></li>
                          </ul>
                      </li>
                      <li><a href="http://www.yqrc.com/show_company.asp?company_id=11637&vcod=yqrcod" target="_blank">人才招聘</a></li>
                      <li class="dropdown">
                          <a href="contact.html" class="dropdown-toggle" data-toggle="dropdown">
                              联系我们
                          </a>
                          <ul class="dropdown-menu">
                              <li><a href="contact.html">联系方式</a></li>
                              <li><a href="map.html">地图导航</a></li>
                          </ul>
                      </li>
                  </ul>
                  <div class="login-lang pull-right hidden-xs">
                      <div class="lang pull-left m">
                          <a href="javascript:;" class="on"><img src="<?php echo e(asset('static/home/img/shop.png')); ?>"><i class="arrow"></i></a>
                          <ul class="langnav">
                              <li><a href="" target="_blank">天猫</a></li>
                              <li><a href="" target="_blank">阿里巴巴</a></li>
                          </ul>
                      </div>
                      <div class="line1 pull-left"></div>
                      <div class="lang pull-left m">
                          <a href="javascript:;" class="on"><img src="<?php echo e(asset('static/home/img/country_icon.png')); ?>"><i class="arrow"></i></a>
                          <ul class="langnav">
                              <li><a href="" target="_blank">中文</a></li>
                              <li><a href="" target="_blank">English</a></li>
                          </ul>
                      </div>
                  </div>
                  <script type="text/javascript">
                      jQuery(".login-lang").slide({ type:"menu",  titCell:".m", targetCell:"ul.langnav",effect:"slideDown", delayTime:500, triggerTime:0,returnDefault:true  });
                  </script>
              </div>
          </div>
      </nav>

      <!--MobNav.end-->
    <!--</div>-->

  </div>
</div>
