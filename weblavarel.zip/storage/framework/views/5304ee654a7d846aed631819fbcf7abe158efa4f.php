<?php $__env->startSection('title','新闻中心'.'-'.$system['title']); ?>
<?php $__env->startSection('keywords', $system['keywords']); ?>
<?php $__env->startSection('description', $system['description']); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('home/header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<script type="text/javascript">
    var hdnav='2';
    $('.pcnavBar ul.pcnav>li:eq('+hdnav+')').addClass("on");
</script>
<script type="text/javascript">
 jQuery(".pcnavBar .pcnav").slide({ type:"menu",  titCell:".m", targetCell:".sub",effect:"slideDown", delayTime:500, triggerTime:0,returnDefault:true  });
</script>


<div class="nyslide" style="background:url(<?php echo e(asset('static/home/img/newsny.jpg')); ?>) no-repeat center top; background-size:cover;">
    <ul>
        <li class="ch wow fadeInLeft" data-wow-delay="0.3s">
            <span class="cn">新闻资讯</span>
            <span class="en text-uppercase">news </span>
        </li>
    </ul>
</div>

<!--inspage.start-->

<div id="inspage">
    <div class="inspagebox clearfix">

        <!--ipad.mobile-->
        <div class="mobinsrightnav clearfix ">
            <a href="news.html">
                新闻资讯
            </a>
        </div>
        <script type="text/javascript">
            var hdnav='0';
            $('.mobinsrightnav>a:eq('+hdnav+')').addClass("cur");
        </script>
        <div class="insleft">
            <div class="title wow fadeInUp">
                <p class="cn">了解金安电气的最新动态</p>
                <p class="en">Learn about the latest developments in Jinan</p>
            </div>
            <div class="insinfo">
                <div class="newsinfo clearfix wow fadeInUp">
                   <div class="viewtit">
                       <h2><?php echo e($data->name); ?></h2>
                       <p><?php echo e($data->time); ?></p>
                   </div>
                    <div class="viewinfo">
                               <?php echo $data->info; ?>

                      </div>
                    <div class="viewbot clearfix">
                        <div class="infoctrl pull-left wow fadeInUp">
                            <p class="pgdn1">上一条：<?php if(empty($prev)): ?>
                                没有了  <?php else: ?> <a href="<?php echo e(route('newsView',$prev->id)); ?>"><?php echo e($prev->name); ?></a>
                            <?php endif; ?></p>
                            <p class="pgdn">下一条：<?php if(empty($next)): ?>
                                没有了  <?php else: ?> <a href="<?php echo e(route('newsView',$next->id)); ?>"><?php echo e($next->name); ?></a>
                            <?php endif; ?></p>
                        </div>
                        <div class="backlistbtn pull-right"><a href="javascript:history.go(-1);">返回</a></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="insrightnav">
            <a href="news.html">
                新闻资讯
            </a>
        </div>
        <script type="text/javascript">
            var hdnav='0';
            $('.insrightnav>a:eq('+hdnav+')').addClass("cur");
        </script>
    </div>
</div>

<div id="backhome">
    <a href="/"><span><i></i>返回首页</span></a>
</div>


<?php echo $__env->make('home/foot', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>