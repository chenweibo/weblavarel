<?php

return [

'title'=>'123',
'en_title'=>'22',
'keywords'=>'3',
'description'=>'123',
'tel'=>'123',
'phone'=>'23',
'code'=>'12',
'mail'=>'3',
'fax'=>'123',
'address'=>'123',
'icp'=>'34',

];