<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Example</title>
</head>
<body>
<div id="app"></div>
@extends('layouts.app')

@section('content')
    <example></example>
@endsection

</body>
</html>
